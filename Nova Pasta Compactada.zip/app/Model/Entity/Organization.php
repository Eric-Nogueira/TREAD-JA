<?php

namespace App\Model\Entity;

Class Organization{
    public $id = 1;
    public $name = "Tread JA";

    public $about = "Projeto realizado por alunos segundo ano do ensino médio integrado ao curso de informática par internet do Instituto Federal Baiano - Campus Guanambi como material para obtenção de nota nas disciplinas de Programação de Sistemas WEB I, Banco de Dados, Análise de Sistemas WEB e Projeto Integrador I.";
}