<?php

namespace App\Model\Entity;

class VagaItem
{
    public $titulo;
    public $CNPJempresa;
}